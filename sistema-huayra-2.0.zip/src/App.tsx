/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Globe, 
  Share2, 
  Workflow, 
  CalendarCheck, 
  MapPin, 
  Building2, 
  Home, 
  Building, 
  Play, 
  CheckCircle2, 
  Sparkles,
  ArrowRight,
  Cpu,
  Video
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-50 font-sans selection:bg-emerald-500/30">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <InteractiveDemo />
        <Pricing />
      </main>
      <Footer />
    </div>
  );
}

function Navbar() {
  return (
    <nav className="fixed top-0 w-full z-50 bg-zinc-950/80 backdrop-blur-md border-b border-zinc-800/50">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-zinc-950" />
          </div>
          <span className="text-xl font-bold tracking-tight">Sistema Huayra</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
          <a href="#features" className="hover:text-zinc-50 transition-colors">Características</a>
          <a href="#demo" className="hover:text-zinc-50 transition-colors">Demo IA</a>
          <a href="#pricing" className="hover:text-zinc-50 transition-colors">Precios</a>
        </div>
        <button className="px-4 py-2 text-sm font-medium bg-zinc-100 text-zinc-900 rounded-full hover:bg-white transition-colors">
          Comenzar
        </button>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-emerald-900/20 via-zinc-950 to-zinc-950 -z-10" />
      <div className="max-w-7xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-sm font-medium mb-8 border border-emerald-500/20"
        >
          <Sparkles className="w-4 h-4" />
          <span>Plataforma Inmobiliaria de Nueva Generación</span>
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-5xl md:text-7xl font-bold tracking-tighter mb-6 leading-tight"
        >
          Vende Desarrollos con <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">
            Inteligencia Artificial
          </span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-lg md:text-xl text-zinc-400 max-w-2xl mx-auto mb-10"
        >
          Automatizaciones, CRM todo en uno, VR Tours y generación de videos FPV con IA. 
          Conecta con 30+ portales internacionales y domina el mercado.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button className="w-full sm:w-auto px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-semibold rounded-full transition-all flex items-center justify-center gap-2">
            Ver Demo <Play className="w-4 h-4 fill-current" />
          </button>
          <button className="w-full sm:w-auto px-8 py-4 bg-zinc-800 hover:bg-zinc-700 text-zinc-50 font-semibold rounded-full transition-all border border-zinc-700">
            Agendar Llamada
          </button>
        </motion.div>
      </div>
    </section>
  );
}

function Features() {
  const features = [
    {
      icon: <Globe className="w-6 h-6 text-emerald-400" />,
      title: "Growth Hack Internacional",
      description: "Aprovecha 30+ portales inmobiliarios con poco tráfico local pero alta afluencia de nichos internacionales."
    },
    {
      icon: <Share2 className="w-6 h-6 text-cyan-400" />,
      title: "Inventario Centralizado",
      description: "Manejo mediante Drive upload o share link. Multipublicación y sincronización vía APIs o extensión de Claude."
    },
    {
      icon: <Workflow className="w-6 h-6 text-purple-400" />,
      title: "CRM y Funnel Interno",
      description: "Sistema tipo GoHighLevel/ClickUp Agent, pero simplificado y todo en uno para coordinar el flujo."
    },
    {
      icon: <CalendarCheck className="w-6 h-6 text-amber-400" />,
      title: "Agendamiento Inteligente",
      description: "Calendarización automática de leads calificados inmediatamente después de que ven el tour VR."
    }
  ];

  return (
    <section id="features" className="py-24 bg-zinc-900/50 border-y border-zinc-800/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ecosistema Completo</h2>
          <p className="text-zinc-400 max-w-2xl mx-auto">
            Huayra coordina agentes de IA y automatizaciones para que tú solo te enfoques en cerrar ventas.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-zinc-800/50 flex items-center justify-center mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-zinc-400 text-sm leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function InteractiveDemo() {
  const [width, setWidth] = useState<string>('20');
  const [length, setLength] = useState<string>('50');
  const [devType, setDevType] = useState<string>('edificio');
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<{ prompt: string, image: string } | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const promptText = `Actúa como un director de arte de IA y experto en bienes raíces. 
      Genera un prompt detallado en INGLÉS (ideal para Sora, Runway o Veo) para crear un micro-video hiperrealista con drones FPV mostrando un desarrollo arquitectónico.
      
      Datos del terreno:
      - Tipo de desarrollo: ${devType}
      - Dimensiones: ${width}m de frente x ${length}m de fondo
      - Ubicación: Zona de alta plusvalía (estilo Angelópolis)
      
      El prompt debe describir:
      1. El movimiento dinámico de la cámara FPV (swooping, diving, gliding).
      2. La iluminación (golden hour, cinematic lighting).
      3. Los materiales del edificio y el diseño arquitectónico moderno.
      4. El entorno y paisajismo.
      
      Devuelve SOLO el texto del prompt en inglés, sin introducciones ni explicaciones.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: promptText,
      });

      // Select a placeholder image based on dev type
      const imageMap: Record<string, string> = {
        'edificio': 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800',
        'condos': 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800',
        'villas': 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800',
        'condominio': 'https://images.unsplash.com/photo-1460317442991-0ec209397118?auto=format&fit=crop&q=80&w=800'
      };

      setResult({
        prompt: response.text || 'Error generating prompt.',
        image: imageMap[devType] || imageMap['edificio']
      });
    } catch (error) {
      console.error("Error generating content:", error);
      setResult({
        prompt: "Error de conexión con la IA. Por favor, intenta de nuevo.",
        image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <section id="demo" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 flex items-center gap-3">
            <Cpu className="w-8 h-8 text-emerald-400" />
            Demo del Sistema
          </h2>
          <p className="text-zinc-400 max-w-2xl">
            Experimenta el motor de IA de Huayra. Selecciona las dimensiones del terreno y el tipo de desarrollo para generar un blueprint hiperrealista y el prompt exacto para crear un video FPV con IA.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column: Video */}
          <div className="rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 shadow-2xl">
            <div className="p-4 border-b border-zinc-800 flex items-center gap-2 bg-zinc-900/50">
              <Video className="w-5 h-5 text-zinc-400" />
              <span className="font-medium text-sm text-zinc-300">Video FPV de Referencia</span>
            </div>
            <div className="aspect-video w-full">
              <iframe 
                width="100%" 
                height="100%" 
                src="https://www.youtube.com/embed/_QfS8rxNFMU?autoplay=1&mute=1&loop=1&playlist=_QfS8rxNFMU" 
                title="FPV Drone Real Estate" 
                frameBorder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
                className="w-full h-full object-cover"
              ></iframe>
            </div>
            <div className="p-6">
              <h3 className="text-lg font-semibold mb-2">Animaciones con Renders IA</h3>
              <p className="text-sm text-zinc-400">
                El sistema Huayra toma videos base como este y utiliza IA generativa para superponer renders hiperrealistas, mostrando el desarrollo terminado antes de poner la primera piedra.
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Generator */}
          <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-6 shadow-2xl flex flex-col">
            <div className="flex items-center gap-2 mb-6">
              <MapPin className="w-5 h-5 text-emerald-400" />
              <h3 className="text-lg font-semibold">Geoloc Pinpoint & Dimensionado</h3>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-xs font-medium text-zinc-400 uppercase tracking-wider mb-2">Frente (m)</label>
                <input 
                  type="number" 
                  value={width}
                  onChange={(e) => setWidth(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-zinc-100 focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 uppercase tracking-wider mb-2">Fondo (m)</label>
                <input 
                  type="number" 
                  value={length}
                  onChange={(e) => setLength(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-zinc-100 focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>
            </div>

            <div className="mb-8">
              <label className="block text-xs font-medium text-zinc-400 uppercase tracking-wider mb-2">Tipo de Desarrollo</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'edificio', label: 'Edificio (Max 11 pisos)', icon: <Building className="w-4 h-4" /> },
                  { id: 'condos', label: 'Condos', icon: <Building2 className="w-4 h-4" /> },
                  { id: 'villas', label: 'Villas', icon: <Home className="w-4 h-4" /> },
                  { id: 'condominio', label: 'Condominio (Medio)', icon: <MapPin className="w-4 h-4" /> }
                ].map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setDevType(type.id)}
                    className={`flex items-center gap-2 px-4 py-3 rounded-lg border text-sm font-medium transition-all ${
                      devType === type.id 
                        ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' 
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    {type.icon}
                    <span className="truncate">{type.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full py-4 bg-zinc-100 hover:bg-white text-zinc-900 font-semibold rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mb-8"
            >
              {isGenerating ? (
                <span className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 animate-pulse" /> Generando con IA...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" /> Generar Blueprint y Prompt IA
                </span>
              )}
            </button>

            {/* Results Area */}
            {result && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mt-auto border-t border-zinc-800 pt-6"
              >
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-xs font-medium text-zinc-400 uppercase tracking-wider mb-3">Mini Render Blueprint (LOD BMI)</h4>
                    <div className="aspect-[4/3] rounded-lg overflow-hidden border border-zinc-800 relative group">
                      <img src={result.image} alt="Blueprint" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 to-transparent flex items-end p-3">
                        <span className="text-xs font-mono text-emerald-400">{width}m x {length}m • {devType.toUpperCase()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <h4 className="text-xs font-medium text-zinc-400 uppercase tracking-wider mb-3">Prompt Generado para Video IA</h4>
                    <div className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg p-4 text-xs font-mono text-zinc-300 overflow-y-auto max-h-[200px] custom-scrollbar">
                      {result.prompt}
                    </div>
                    <button 
                      onClick={() => navigator.clipboard.writeText(result.prompt)}
                      className="mt-3 text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 transition-colors"
                    >
                      <Share2 className="w-3 h-3" /> Copiar Prompt
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section id="pricing" className="py-24 bg-zinc-950 border-t border-zinc-800/50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Inversión Inteligente</h2>
          <p className="text-zinc-400">
            Obtén tecnología valuada en miles de dólares por una fracción del costo.
          </p>
        </div>

        <div className="relative rounded-3xl bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-800 p-1 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-md h-[1px] bg-gradient-to-r from-transparent via-emerald-500 to-transparent" />
          
          <div className="p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-12 border-b border-zinc-800/50 pb-12">
              <div>
                <div className="text-zinc-500 line-through text-xl mb-2">Costo Real: $1,000 USD</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl md:text-6xl font-bold text-white">$100</span>
                  <span className="text-zinc-400 text-xl">/ mes</span>
                </div>
                <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-sm font-medium">
                  + 2.5% de comisión sobre venta (share)
                </div>
              </div>
              
              <button className="w-full md:w-auto px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold rounded-xl transition-all flex items-center justify-center gap-2 text-lg">
                Comenzar Ahora <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {[
                "Plataforma de automatizaciones y agentes",
                "Growth hack: 30+ portales internacionales",
                "Manejo de inventario centralizado (Drive/Share)",
                "Multipublicación y sincronización (APIs/Claude)",
                "Sistema de funnel y CRM interno todo en uno",
                "Calendarización de leads post-VR Tour",
                "Generador de renders y prompts IA",
                "Soporte prioritario"
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="text-zinc-300">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="py-12 border-t border-zinc-800/50 bg-zinc-950 text-center text-zinc-500 text-sm">
      <div className="flex items-center justify-center gap-2 mb-4">
        <Sparkles className="w-4 h-4 text-emerald-500" />
        <span className="font-bold text-zinc-300">Sistema Huayra</span>
      </div>
      <p>© {new Date().getFullYear()} Sistema Huayra. Todos los derechos reservados.</p>
    </footer>
  );
}
